References:

This repository contains a basic ASP.NET Core MVC web application developed in Visual Studio.

The project follows the **MVC (Model-View-Controller)** architecture and was scaffolded using built-in Visual Studio tools to quickly
generate controllers, views, and models.

Links used to help create the project:

[Microsoft Docs – ASP.NET Core MVC Overview](https://learn.microsoft.com/en-us/aspnet/core/mvc/overview?view=aspnetcore-7.0)
[Microsoft Docs – Scaffolding in ASP.NET Core](https://learn.microsoft.com/en-us/aspnet/core/tutorials/first-mvc-app/controller-actions?view=aspnetcore-7.0)
[Tutorial – Build a web app with ASP.NET Core MVC](https://learn.microsoft.com/en-us/aspnet/core/tutorials/first-mvc-app/start-mvc?view=aspnetcore-7.0&tabs=visual-studio)
[Entity Framework Core Getting Started](https://learn.microsoft.com/en-us/ef/core/get-started/overview/install)
[Razor Pages vs MVC](https://learn.microsoft.com/en-us/aspnet/core/razor-pages/?view=aspnetcore-7.0)
